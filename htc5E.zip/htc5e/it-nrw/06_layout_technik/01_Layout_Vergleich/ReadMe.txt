﻿Die Beispiele zeigen verschiedene Techniken, mit denen sich - mehr oder weniger gut - ein
'Holy Grail Layout' erzielen lässt:

- Im Unterverzeichnis 'text_floats' sind grundlegende Float-Stolpersteine wie
  -- Clearing
  -- BFG
  -- Containing Floats
  thematisiert.
- 01_Floats_column_height zeigt, wie man die Spalten 'durchfärbt' (padding-bottom/neg. margin-bottom/overflow)
- 02_Inline-Block_Layout zeigt die Probleme mit whitespace zwischen den Elementen.
- 03_CSS_TableLayout zeigt ein ausschließlich mit CSS erzieltes TabellenLayout, 
  das semantisch vertretbar ist (umstrittene Technik!)
- 04_AbsoluteLayout zeigt einen Versuch - und seine Grenzen - Bereiche absolut zu positionieren.
- 05_Floats_neg_margin zeigt, wie man die Reihenfolge der dargestellten Spalten unabhängig von
  der Abfolge der zugehörigen Bereiche im HTML Code machen kann, auf Basis von Floats mit negativen margins.
- 05_Floats_neg_margin_animate zeigt gleiches nochmals als Hover-Animation (zum besseren Verständnis der negativen margins)
- 06_Flexbox veranschaulicht, wie einfach obige Lösungen mit Flexbox umgesetzt werden können. 